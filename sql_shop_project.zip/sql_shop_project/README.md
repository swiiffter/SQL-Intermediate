
# SQL E-Commerce Project

This project simulates a simple e-commerce database system with five main entities: customers, products, orders, order items, and product categories.

## Features

- Demonstrates use of SQL commands: `SELECT`, `WHERE`, `LIKE`, `IN`, `BETWEEN`, `AS`, `GROUP BY`, `HAVING`, and all types of `JOIN`.
- Sample data is provided to test the queries.
- Each query is written to reflect real-world business logic.

## Tables

- `categories`: Product categories
- `products`: Product details
- `customers`: Customer information
- `orders`: Customer orders
- `order_items`: Items within orders

## How to Use

1. Copy and run the script `ecommerce_project.sql` in your preferred SQL environment (e.g. MySQL, PostgreSQL).
2. Run the example queries included at the bottom of the file to test out the SQL operations.

## License

This project is for educational use.
